'''
This is a file for the first homework assignment in the 
Python is Easy class from Pirple
'''

#Artist and Genre info
Artist = "Marshmello"
Genre = "Blocks"
DurationInMinutes = 3.483

#Producer and record label info.  
Producer = "Wild Bill"
Label = "House label"
NumOfSpotifyListens = 1400000
YearRecorded = 2016

#Marketing and sales info
AlbumName = "Joytime"
AlbumArtwork = "Some Lady"
SalesinUSDollars = 4350000.27

print(Artist)
print(Genre)
print(DurationInMinutes)
print(Producer)
print(Label)
print(NumOfSpotifyListens)
print(YearRecorded)
print(AlbumName)
print(AlbumArtwork)
print(SalesinUSDollars)