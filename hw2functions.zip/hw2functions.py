#Hw 2 - Functions

def AlbumName():
    print("Joytime")

def Label():
    print("House Label")

def Producer():
    print("Wild Bill")

def booTest():
    var1 = False
    return var1



AlbumName()
Label()
Producer()
print(booTest())